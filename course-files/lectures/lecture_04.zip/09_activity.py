# Modify your code from Activity 8 such that the banner character
# can be any character, but defaults to the asterik character if
# no banner characted argument is specified