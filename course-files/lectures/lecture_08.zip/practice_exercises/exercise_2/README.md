---
layout: default
title: Loops Exercise 2
nav_exclude: True
---

# Exercise 2: Instructions
Instructions available in the [Google Doc](https://docs.google.com/document/d/1wxdKnZXXDiqnhJHsbqJm9TQlLqPwU2guwC475X5Ab1w/edit?usp=sharing)